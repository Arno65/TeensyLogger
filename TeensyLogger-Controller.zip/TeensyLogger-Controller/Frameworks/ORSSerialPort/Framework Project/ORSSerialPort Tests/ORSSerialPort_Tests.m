//
//  ORSSerialPort_Tests.m
//  ORSSerialPort Tests
//
//  Created by Andrew Madsen on 8/1/15.
//  Copyright (c) 2015 Open Reel Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <XCTest/XCTest.h>

@interface ORSSerialPort_Tests : XCTestCase

@end

@implementation ORSSerialPort_Tests

@end
